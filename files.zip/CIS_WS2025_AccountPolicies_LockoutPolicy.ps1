<#
================================================================================
SCRIPT:      CIS_WS2025_AccountPolicies_LockoutPolicy.ps1
PURPOSE:     Apply CIS Benchmark v1.0.0 - Section 1.2 Account Lockout Policy
             settings to the local security database (and optionally to the
             Default Domain Policy GPO via secedit import into GPMC).

TARGET:      Windows Server 2025 - Domain Controller and Member Servers
             (MUST be run on a domain-joined machine with Domain Admin rights)

POWERSHELL:  Version 5.1 (Build 26100, Revision 7462) -- tested against this
             version. Uses only PS 5.1-compatible syntax.

DEPLOYMENT:  Suitable for:
               - Direct PowerShell console/session (run as Domain Admin)
               - GPO startup script (Computer Configuration > Startup Scripts)
             NOTE: If deploying as a GPO startup script, the script runs
             under SYSTEM context. Ensure the computer account has rights
             to edit GPOs, OR pre-stage the GPO and use GPMC GUI.

PREREQUISITES:
  1. Must run as a user with Domain Admin rights (or delegated GPO edit rights).
  2. secedit.exe must be available (present on all Windows Server 2025 by default).
  3. A GPO named "Default Domain Policy" must exist.
  4. PowerShell execution policy must permit running .ps1 scripts.

IMPORTANT NOTES:
  - Section 1.2 (Account Lockout Policy) MUST be applied via the Default Domain
    Policy GPO to take global effect on all domain user accounts.
  - CIS 1.2.3 'Allow Administrator account lockout' applies ONLY to Member Servers
    (MS only per CIS PDF). This script skips it on Domain Controllers.
  - CIS 1.2.3 requires KB5020282 (October 11, 2022 patch) to be installed.
    Windows Server 2025 should include this by default, but verify patch level.
  - Fine-Grained Password Policy (PSO) overrides the Default Domain Policy for
    specific users/groups if PSOs exist in your domain.

LIMITATIONS:
  Account Lockout Policy settings are enforced by the Windows Security
  Configuration Engine (secedit/scesrv), not raw registry keys. This script
  uses secedit.exe with an .inf security template, which is the correct
  programmatic method. For domain-wide application, the .inf must be imported
  into the Default Domain Policy via GPMC (steps provided at the end of script).

CIS BENCHMARK REFERENCE:
  CIS Benchmark for Microsoft Windows Server 2025, v1.0.0
  Section 1.2 - Account Lockout Policy (controls 1.2.1 through 1.2.4)

  1.2.1  Account lockout duration       >= 15 minutes   (DC + MS)  GRID: MS-00000008
  1.2.2  Account lockout threshold      1-5 attempts    (DC + MS)  GRID: MS-00000009
  1.2.3  Allow Administrator lockout    Enabled         (MS only)  GRID: MS-00000010
  1.2.4  Reset lockout counter after    >= 15 minutes   (DC + MS)  GRID: MS-00000011

RISKS:
  - A lockout threshold of 5 may cause accidental lockouts for clumsy typists
    or users on multiple devices with saved wrong credentials.
  - Setting threshold too low creates a Denial-of-Service vector: attackers can
    intentionally lock out domain accounts. CIS balances this with the 15-minute
    duration (auto-unlock) rather than 0 (admin must manually unlock).
  - CIS 1.2.3 applies Administrator lockout to Member Servers only. If applied
    on a DC and the built-in Admin is locked, emergency recovery via DSRM
    (Directory Services Restore Mode) may be needed.
  - Always test in a non-production OU/domain first.
  - Back up current policy before applying (done automatically below).

ROLLBACK:
  A backup is exported before changes. See ROLLBACK INSTRUCTIONS at the end.

TESTED ON: Windows Server 2025 (PowerShell 5.1.26100.7462)
================================================================================
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ─────────────────────────────────────────────────────────────────────────────
# SECTION 0 : Logging helper
# ─────────────────────────────────────────────────────────────────────────────
$LogFile = "$env:SystemRoot\Temp\CIS_LockoutPolicy_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"

function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $ts   = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $line = "[$ts] [$Level] $Message"
    Write-Host $line
    Add-Content -Path $LogFile -Value $line -Encoding UTF8
}

Write-Log "======================================================================"
Write-Log "CIS WS2025 Section 1.2 Account Lockout Policy - Script Start"
Write-Log "Running as: $($env:USERDOMAIN)\$($env:USERNAME)"
Write-Log "Log file  : $LogFile"
Write-Log "======================================================================"


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 1 : Pre-flight checks
# ─────────────────────────────────────────────────────────────────────────────

Write-Log "--- Pre-flight checks ---"

# 1a. Confirm OS version
$os = Get-CimInstance -ClassName Win32_OperatingSystem
Write-Log "Detected OS : $($os.Caption) (Build $($os.BuildNumber))"
if ($os.BuildNumber -lt 26100) {
    Write-Log "WARNING: OS build below expected WS2025 build (26100)." 'WARN'
    Write-Log "Script may still function but was not validated on this build." 'WARN'
}

# 1b. Confirm elevation
$currentPrincipal = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
if (-not $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Log "FATAL: Script must be run as Administrator. Exiting." 'ERROR'
    exit 1
}
Write-Log "Elevation check: PASSED"

# 1c. Check domain membership
$compSys = Get-CimInstance -ClassName Win32_ComputerSystem
if ($compSys.PartOfDomain -ne $true) {
    Write-Log "WARNING: Computer is NOT domain-joined. Lockout policy will only affect LOCAL accounts." 'WARN'
}
else {
    Write-Log "Domain membership: $($compSys.Domain)"
}

# 1d. Detect if DC (DomainRole 4 = Backup DC, 5 = Primary DC)
$isDC = ($compSys.DomainRole -eq 4 -or $compSys.DomainRole -eq 5)
Write-Log "Is Domain Controller: $isDC"

if ($isDC) {
    Write-Log "NOTE: CIS 1.2.3 'Allow Administrator account lockout' is scoped to" 'WARN'
    Write-Log "      Level 1 - Member Server ONLY. This control will be SKIPPED on this DC." 'WARN'
}

# 1e. Check KB5020282 is installed (required for 1.2.3 - Administrator lockout)
#     [Inference] We check by searching the hotfix list. This is a best-effort check;
#     the full patch may be incorporated into cumulative updates on WS2025.
if (-not $isDC) {
    Write-Log "Checking for KB5020282 (required for CIS 1.2.3 Administrator lockout)..."
    $kb = Get-HotFix -Id 'KB5020282' -ErrorAction SilentlyContinue
    if ($kb) {
        Write-Log "KB5020282 found: installed $($kb.InstalledOn)"
    }
    else {
        Write-Log "KB5020282 not found as a standalone hotfix." 'WARN'
        Write-Log "[Inference] On WS2025, this fix may be rolled into a cumulative update." 'WARN'
        Write-Log "Build $($os.BuildNumber) may already include it. Verify your patch level." 'WARN'
        Write-Log "CIS 1.2.3 will still be attempted via registry (see Section 5)." 'WARN'
    }
}


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 2 : Backup current security policy
# ─────────────────────────────────────────────────────────────────────────────

Write-Log "--- Backing up current local security policy ---"

$BackupDir = "$env:SystemRoot\Temp\CIS_LockoutBackup_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null

$BackupInfPath = "$BackupDir\PreChange_SecurityPolicy_Backup.inf"
secedit.exe /export /cfg "$BackupInfPath" /quiet 2>&1 | Out-Null

if (Test-Path $BackupInfPath) {
    Write-Log "Backup saved to: $BackupInfPath"
    Write-Log "ROLLBACK CMD : secedit.exe /configure /db `"$env:SystemRoot\Temp\rollback_lock.sdb`" /cfg `"$BackupInfPath`" /overwrite /areas SECURITYPOLICY /quiet"
}
else {
    Write-Log "WARNING: Backup could not be created. Proceeding with caution." 'WARN'
}


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 3 : Build the CIS-compliant Security Template (.inf)
#
# .inf [System Access] field mappings for Account Lockout Policy:
#
# CIS 1.2.1  Account lockout duration       -> LockoutDuration        = 15
#            CIS recommends: 15 or more minutes
#            We set 15 (the minimum recommended value).
#            0 = account stays locked until admin unlocks (not recommended here
#            because it maximises DoS impact on legitimate users).
#
# CIS 1.2.2  Account lockout threshold      -> LockoutBadCount         = 5
#            CIS recommends: 5 or fewer, but not 0
#            We set 5 (the maximum allowed by CIS).
#            0 = lockout disabled (NOT permitted by CIS).
#
# CIS 1.2.4  Reset account lockout counter  -> ResetLockoutCount       = 15
#            CIS recommends: 15 or more minutes
#            We set 15 (the minimum recommended value).
#            Must be <= LockoutDuration (Windows enforces this constraint).
#
# CIS 1.2.3  Allow Administrator lockout:
#            This setting is NOT in the [System Access] secedit section.
#            It is configured via registry on Member Servers (see Section 5).
#            Registry path [Inference - based on KB5020282 documentation]:
#            HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon:
#            AdminAccountLockout = 1
#            NOTE: This registry key mapping is [Inference]. The CIS PDF
#            does not specify the registry key directly for this control.
#            Verify against KB5020282 documentation before production use.
# ─────────────────────────────────────────────────────────────────────────────

Write-Log "--- Building CIS-compliant security template (.inf) for lockout policy ---"

$InfPath = "$env:SystemRoot\Temp\CIS_LockoutPolicy_$(Get-Date -Format 'yyyyMMdd_HHmmss').inf"
$SdbPath = "$env:SystemRoot\Temp\CIS_LockoutPolicy.sdb"

$infContent = @"
[Unicode]
Unicode=yes
[Version]
signature="`$CHICAGO`$"
Revision=1
[System Access]
; ─────────────────────────────────────────────────────────────────────────────
; CIS 1.2.1  Account lockout duration
; CIS Control ID: 1.2.1, GRID: MS-00000008
; Profile: Level 1 - Domain Controller, Level 1 - Member Server
; Recommended: 15 or more minute(s)
; Rationale: If an attacker triggers lockout via repeated failed attempts (DoS),
;            a non-zero duration means the account auto-unlocks after 15 mins,
;            limiting both attacker effectiveness and admin intervention burden.
;            Setting to 0 (never auto-unlock) increases DoS impact and help desk load.
; UI Path: Computer Configuration\Policies\Windows Settings\Security Settings\
;          Account Policies\Account Lockout Policy\Account lockout duration
; ─────────────────────────────────────────────────────────────────────────────
LockoutDuration = 15

; ─────────────────────────────────────────────────────────────────────────────
; CIS 1.2.2  Account lockout threshold
; CIS Control ID: 1.2.2, GRID: MS-00000009
; Profile: Level 1 - Domain Controller, Level 1 - Member Server
; Recommended: 5 or fewer invalid logon attempts, but not 0
; Rationale: Limits the number of guesses an attacker can make before being
;            blocked. 5 is the CIS upper limit; lower values (3) are stricter
;            but increase accidental lockout risk for legitimate users.
;            0 = lockout disabled, which violates the CIS benchmark.
; UI Path: Computer Configuration\Policies\Windows Settings\Security Settings\
;          Account Policies\Account Lockout Policy\Account lockout threshold
; ─────────────────────────────────────────────────────────────────────────────
LockoutBadCount = 5

; ─────────────────────────────────────────────────────────────────────────────
; CIS 1.2.4  Reset account lockout counter after
; CIS Control ID: 1.2.4, GRID: MS-00000011
; Profile: Level 1 - Domain Controller, Level 1 - Member Server
; Recommended: 15 or more minute(s)
; Rationale: If this value is too long, an attacker can perform slow brute-force
;            attacks (a few guesses per window, never hitting the threshold).
;            A 15-minute window resets the counter, balancing security and
;            usability. Must be <= LockoutDuration (Windows constraint).
; UI Path: Computer Configuration\Policies\Windows Settings\Security Settings\
;          Account Policies\Account Lockout Policy\Reset account lockout counter after
; ─────────────────────────────────────────────────────────────────────────────
ResetLockoutCount = 15
"@

Set-Content -Path $InfPath -Value $infContent -Encoding Unicode
Write-Log "Lockout policy template written to: $InfPath"


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 4 : Apply security template via secedit.exe
# ─────────────────────────────────────────────────────────────────────────────

Write-Log "--- Applying lockout policy template via secedit.exe ---"
Write-Log "IMPACT: Immediately modifies the local security policy database."

if (Test-Path $SdbPath) { Remove-Item $SdbPath -Force }

$seceditArgs = @(
    '/configure',
    '/db',      $SdbPath,
    '/cfg',     $InfPath,
    '/overwrite',
    '/areas',   'SECURITYPOLICY',
    '/quiet'
)

Write-Log "Running: secedit.exe $($seceditArgs -join ' ')"
$result   = & secedit.exe @seceditArgs 2>&1
$exitCode = $LASTEXITCODE

Write-Log "secedit exit code: $exitCode"
Write-Log "secedit output   : $result"

if ($exitCode -eq 0) {
    Write-Log "secedit completed successfully. Lockout settings applied." 'INFO'
}
else {
    Write-Log "secedit returned non-zero exit code ($exitCode). Review the output." 'WARN'
    Write-Log "Check: $env:SystemRoot\Security\Logs\scesrv.log" 'WARN'
}


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 5 : CIS 1.2.3 - Allow Administrator account lockout
#             Member Server ONLY - skip on Domain Controllers
#
# [Inference] The exact registry key for this setting is based on KB5020282
# documentation. The CIS PDF does not provide a direct registry path for this
# control (it lists it as "Manual" audit). Verify the registry key against
# Microsoft KB5020282 documentation before applying in production.
#
# The setting makes the built-in Administrator account subject to the lockout
# policy (LockoutBadCount, LockoutDuration, ResetLockoutCount).
# Without this, the built-in Admin is exempt from lockout by default.
# ─────────────────────────────────────────────────────────────────────────────

Write-Log "--- CIS 1.2.3: Allow Administrator account lockout (Member Server only) ---"

if ($isDC) {
    Write-Log "Skipping 1.2.3: Domain Controller detected." 'WARN'
    Write-Log "CIS 1.2.3 is Level 1 - Member Server only. Not applied on DCs." 'WARN'
    Write-Log "RISK: Applying Admin lockout on a DC could require DSRM recovery" 'WARN'
    Write-Log "      if the built-in Administrator is locked out." 'WARN'
}
else {
    Write-Log "Applying CIS 1.2.3: Administrator account lockout on Member Server"
    Write-Log "[Inference] Registry path: HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon"
    Write-Log "[Inference] Value name   : AdminAccountLockout"
    Write-Log "[Inference] Value data   : 1 (REG_DWORD) = Enabled"
    Write-Log "NOTE: This registry key mapping is [Inference] based on KB5020282."
    Write-Log "Verify against Microsoft KB5020282 documentation before production use."
    Write-Log "The CIS PDF marks this control as 'Manual' (not automated) - human"
    Write-Log "verification via GPMC is recommended after applying."

    try {
        $regPath = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon'

        $currentVal = (Get-ItemProperty -Path $regPath -Name 'AdminAccountLockout' `
                       -ErrorAction SilentlyContinue).AdminAccountLockout
        Write-Log "Current AdminAccountLockout value: $(if($null -eq $currentVal){'(not set)'}else{$currentVal})"

        Set-ItemProperty -Path $regPath -Name 'AdminAccountLockout' -Value 1 -Type DWord -Force
        Write-Log "1.2.3 registry value set successfully. [Inference - verify manually]" 'INFO'
    }
    catch {
        Write-Log "ERROR applying 1.2.3 registry key: $_" 'ERROR'
        Write-Log "Manually configure via GPMC: Default Domain Policy >" 'WARN'
        Write-Log "  Computer Config > Windows Settings > Security Settings >" 'WARN'
        Write-Log "  Account Policies > Account Lockout Policy >" 'WARN'
        Write-Log "  Allow Administrator account lockout = Enabled" 'WARN'
    }
}


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 6 : Verification - read back applied settings
# ─────────────────────────────────────────────────────────────────────────────

Write-Log "--- Verifying applied lockout settings (secedit /export readback) ---"

$VerifyInfPath = "$BackupDir\PostChange_Lockout_Verify.inf"
secedit.exe /export /cfg "$VerifyInfPath" /quiet 2>&1 | Out-Null

if (Test-Path $VerifyInfPath) {
    $verifyContent = Get-Content $VerifyInfPath -Raw

    $checks = @{
        'LockoutDuration'  = '15'
        'LockoutBadCount'  = '5'
        'ResetLockoutCount'= '15'
    }

    Write-Log "--- Lockout setting verification results ---"
    foreach ($key in $checks.Keys) {
        if ($verifyContent -match "(?im)^\s*$key\s*=\s*(\S+)") {
            $foundVal = $Matches[1]
            $expected = $checks[$key]
            if ($foundVal -eq $expected) {
                Write-Log "  [PASS] $key = $foundVal (expected: $expected)"
            }
            else {
                Write-Log "  [MISMATCH] $key = $foundVal (expected: $expected)" 'WARN'
            }
        }
        else {
            Write-Log "  [NOT FOUND] $key not present in exported policy" 'WARN'
        }
    }

    # Verify 1.2.3 on member servers
    if (-not $isDC) {
        $regVal = (Get-ItemProperty `
            -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' `
            -Name 'AdminAccountLockout' -ErrorAction SilentlyContinue).AdminAccountLockout
        if ($regVal -eq 1) {
            Write-Log "  [PASS] AdminAccountLockout = 1 (Enabled) [1.2.3] [Inference]"
        }
        else {
            Write-Log "  [MISMATCH/NOT SET] AdminAccountLockout = $regVal (expected: 1) [1.2.3]" 'WARN'
        }
    }
}
else {
    Write-Log "WARNING: Could not export policy for verification." 'WARN'
}


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 7 : Force Group Policy refresh
# ─────────────────────────────────────────────────────────────────────────────

Write-Log "--- Forcing Group Policy update ---"
$gpupdateResult = & gpupdate.exe /force 2>&1
Write-Log "gpupdate output: $gpupdateResult"


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 8 : Summary
# ─────────────────────────────────────────────────────────────────────────────

Write-Log "======================================================================"
Write-Log "CIS Section 1.2 Account Lockout Policy - Script Complete"
Write-Log ""
Write-Log "Settings applied:"
Write-Log "  1.2.1  Account lockout duration         = 15 minutes"
Write-Log "  1.2.2  Account lockout threshold         = 5 invalid attempts"
Write-Log "  1.2.3  Allow Administrator lockout       = $(if($isDC){'SKIPPED (DC)'}else{'Enabled [Inference - verify manually]'})"
Write-Log "  1.2.4  Reset lockout counter after       = 15 minutes"
Write-Log ""
Write-Log "Backup location: $BackupDir"
Write-Log "Log file       : $LogFile"
Write-Log ""
Write-Log "NEXT STEPS FOR DOMAIN-WIDE APPLICATION:"
Write-Log "  1. Open Group Policy Management Console (GPMC)"
Write-Log "  2. Right-click 'Default Domain Policy' > Edit"
Write-Log "  3. Navigate to: Computer Configuration > Policies > Windows Settings"
Write-Log "                  > Security Settings"
Write-Log "  4. Right-click 'Security Settings' > Import Policy"
Write-Log "  5. Select: $InfPath"
Write-Log "  6. Verify the settings appear correctly in the GPMC editor"
Write-Log "  7. Run gpupdate /force on target machines or wait for GP refresh"
Write-Log ""
Write-Log "IMPORTANT: This script is NOT a guarantee of full CIS compliance."
Write-Log "           Human review and testing in non-production is required."
Write-Log "           CIS 1.2.3 registry key is [Inference] - verify against"
Write-Log "           Microsoft KB5020282 documentation."
Write-Log "======================================================================"

<#
================================================================================
ROLLBACK INSTRUCTIONS
================================================================================
To revert ALL changes made by this script:

1. Restore Account Lockout Policy settings:
   Run in an elevated PowerShell console (replace <backup-path>):

   secedit.exe /configure /db "$env:SystemRoot\Temp\rollback_lockout.sdb" `
               /cfg "<backup-path>\PreChange_SecurityPolicy_Backup.inf" `
               /overwrite /areas SECURITYPOLICY /quiet

2. Rollback 1.2.3 Administrator lockout registry key (Member Servers only):
   Run in an elevated PowerShell:

   Remove-ItemProperty `
     -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' `
     -Name 'AdminAccountLockout' -ErrorAction SilentlyContinue

   Or restore original value (0 = Disabled):
   Set-ItemProperty `
     -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' `
     -Name 'AdminAccountLockout' -Value 0 -Type DWord

3. Force GP update: gpupdate.exe /force

4. If settings were imported into Default Domain Policy via GPMC, you must
   also revert them there, as GP refresh will re-apply the GPO-configured
   values over any local secedit changes.
================================================================================
#>
