<#
================================================================================
SCRIPT:      CIS_WS2025_AccountPolicies_PasswordPolicy.ps1
PURPOSE:     Apply CIS Benchmark v1.0.0 - Section 1.1 Password Policy settings
             to the Default Domain Policy GPO via the GroupPolicy PowerShell
             module (Set-GPRegistryValue), targeting the HKLM registry hive
             used by Group Policy Security Settings.

TARGET:      Windows Server 2025 - Domain Controller and Member Servers
             (MUST be run on a domain-joined machine with access to GPMC/RSAT)

POWERSHELL:  Version 5.1 (Build 26100, Revision 7462) -- tested against this
             version. Uses only PS 5.1-compatible syntax.

DEPLOYMENT:  Suitable for:
               - Direct PowerShell console/session (run as Domain Admin)
               - GPO startup script (Computer Configuration > Startup Scripts)
             NOTE: If deploying as a GPO startup script, the script runs
             under SYSTEM context. Ensure the computer account has rights
             to edit GPOs, OR pre-stage the GPO and use Set-GPRegistryValue
             from an admin workstation instead.

PREREQUISITES:
  1. Must run as a user with Domain Admin rights (or delegated GPO edit rights).
  2. The GroupPolicy RSAT module must be installed:
       - On DC: available by default
       - On member server: Install-WindowsFeature GPMC
  3. A GPO named "Default Domain Policy" must exist (it does by default in AD).
  4. PowerShell execution policy must permit running .ps1 scripts.
     Suggested: Set-ExecutionPolicy RemoteSigned -Scope LocalMachine

IMPORTANT NOTES:
  - Section 1.1 (Password Policy) and Section 1.2 (Account Lockout Policy)
    MUST be applied via the "Default Domain Policy" GPO to take global effect
    on all domain user accounts. Applying them in any other GPO will only
    affect LOCAL user accounts on computers receiving that GPO.
  - The GroupPolicy module's Set-GPRegistryValue sets registry values that
    correspond to Group Policy Security Settings. However, for certain
    "Security Settings" sub-areas (Password Policy, Account Lockout Policy),
    Windows uses secedit.exe / LGPO-style settings, not raw registry keys,
    for their authoritative enforcement. See LIMITATIONS below.

LIMITATIONS:
  *** CRITICAL - PLEASE READ ***
  Password Policy and Account Lockout Policy settings (Section 1.1 and 1.2)
  are enforced by the Windows Security Configuration Engine (scesrv.dll /
  secedit), NOT by simple registry keys readable by Set-GPRegistryValue.
  The correct authoritative method is one of:
    A) Use the Group Policy Management Console (GPMC) GUI to set these
       values in the Default Domain Policy directly (recommended for AD).
    B) Use secedit.exe with an .inf template file (demonstrated below).
    C) Use the Fine-Grained Password Policy (PSO) via AD cmdlets
       (New-ADFineGrainedPasswordPolicy) for specific users/groups.

  This script uses APPROACH B (secedit.exe with a security template .inf),
  which is the correct programmatic method for local/domain Security Settings
  that does not require GPMC module calls for Password/Lockout policy.

  WARNING: secedit /configure modifies the LOCAL security database on the
  machine where it runs. To apply domain-wide via GPO:
    - Export the .inf content and import it into the Default Domain Policy
      via GPMC GUI, or
    - Use this script via a GPO Computer Startup Script so every DC applies it.

CIS BENCHMARK REFERENCE:
  CIS Benchmark for Microsoft Windows Server 2025, v1.0.0
  Section 1.1 - Password Policy (all controls: 1.1.1 through 1.1.7)
  Profile: Level 1 - Domain Controller AND Level 1 - Member Server
  (except 1.1.6 which is Level 1 - Member Server only)

RISKS:
  - Applying stricter password settings may cause user friction and
    increased help desk calls.
  - Minimum password length of 14 chars may lock out legacy systems
    (Windows 98 / NT 4.0-era) that cannot handle passwords > 14 chars.
  - "Relax minimum password length limits" (1.1.6) is Member Server only;
    do NOT apply to Domain Controllers (see note in the setting below).
  - Always test in a non-production OU/domain first.
  - Back up current policy before applying (backup steps included below).

ROLLBACK:
  A rollback .inf template is exported before changes are applied.
  See the ROLLBACK INSTRUCTIONS at the bottom of this script.

TESTED ON: Windows Server 2025 (PowerShell 5.1.26100.7462)
================================================================================
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ─────────────────────────────────────────────────────────────────────────────
# SECTION 0 : Logging helper
# ─────────────────────────────────────────────────────────────────────────────
$LogFile = "$env:SystemRoot\Temp\CIS_PasswordPolicy_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"

function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $ts  = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $line = "[$ts] [$Level] $Message"
    Write-Host $line
    Add-Content -Path $LogFile -Value $line -Encoding UTF8
}

Write-Log "======================================================================"
Write-Log "CIS WS2025 Section 1.1 Password Policy - Script Start"
Write-Log "Running as: $($env:USERDOMAIN)\$($env:USERNAME)"
Write-Log "Log file  : $LogFile"
Write-Log "======================================================================"


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 1 : Pre-flight checks
# ─────────────────────────────────────────────────────────────────────────────

Write-Log "--- Pre-flight checks ---"

# 1a. Confirm OS is Windows Server 2025
$os = Get-CimInstance -ClassName Win32_OperatingSystem
Write-Log "Detected OS : $($os.Caption) (Build $($os.BuildNumber))"
if ($os.BuildNumber -lt 26100) {
    Write-Log "WARNING: OS build $($os.BuildNumber) is below expected WS2025 build 26100." 'WARN'
    Write-Log "Script may still function but was not validated on this build." 'WARN'
}

# 1b. Confirm running with elevation
$currentPrincipal = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
if (-not $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Log "FATAL: Script must be run as Administrator. Exiting." 'ERROR'
    exit 1
}
Write-Log "Elevation check: PASSED (running as Administrator)"

# 1c. Confirm domain-joined
$compSys = Get-CimInstance -ClassName Win32_ComputerSystem
if ($compSys.PartOfDomain -ne $true) {
    Write-Log "WARNING: This computer does NOT appear to be domain-joined." 'WARN'
    Write-Log "Password Policy set here will only affect LOCAL accounts." 'WARN'
}
else {
    Write-Log "Domain membership: $($compSys.Domain)"
}

# 1d. Detect if this is a Domain Controller
$isDC = ($compSys.DomainRole -eq 4 -or $compSys.DomainRole -eq 5)
Write-Log "Is Domain Controller: $isDC"
if ($isDC) {
    Write-Log "NOTE: 1.1.6 'Relax minimum password length limits' is Level 1 - Member Server ONLY." 'WARN'
    Write-Log "      CIS explicitly scopes this to Member Servers. This script will SKIP 1.1.6 on DCs." 'WARN'
}


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 2 : Backup current Security Policy before any changes
# ─────────────────────────────────────────────────────────────────────────────

Write-Log "--- Backing up current local security policy ---"

$BackupDir = "$env:SystemRoot\Temp\CIS_PolicyBackup_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null

$BackupInfPath = "$BackupDir\PreChange_SecurityPolicy_Backup.inf"

# secedit /export dumps the current effective local security policy to .inf
# This is the correct rollback source for secedit-managed settings.
$seceditExport = secedit.exe /export /cfg "$BackupInfPath" /quiet 2>&1
Write-Log "secedit export result: $seceditExport"

if (Test-Path $BackupInfPath) {
    Write-Log "Backup saved to: $BackupInfPath"
    Write-Log "ROLLBACK: To restore, run:  secedit.exe /configure /db secedit.sdb /cfg `"$BackupInfPath`" /overwrite /quiet"
}
else {
    Write-Log "WARNING: Backup file was not created. Proceeding with caution." 'WARN'
}


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 3 : Build the CIS-compliant Security Template (.inf)
# ─────────────────────────────────────────────────────────────────────────────
#
# .inf format reference: these keys are the standard secedit/LGPO field names
# for Password Policy and Account Lockout Policy. They are well-documented in:
#   Microsoft Security Compliance Toolkit (SCT) .inf files
#   LGPO.exe documentation (Microsoft Security Guidance blog)
#
# CIS 1.1.1  - Enforce password history   -> PasswordHistorySize    = 24
# CIS 1.1.2  - Maximum password age       -> MaximumPasswordAge     = 365
# CIS 1.1.3  - Minimum password age       -> MinimumPasswordAge     = 1
# CIS 1.1.4  - Minimum password length    -> MinimumPasswordLength  = 14
# CIS 1.1.5  - Complexity requirements    -> PasswordComplexity     = 1  (1=Enabled)
# CIS 1.1.6  - Relax min pwd len limits   -> Registry key (NOT secedit field)
#              Applied separately via registry below (Member Server only)
# CIS 1.1.7  - Reversible encryption      -> ClearTextPassword      = 0  (0=Disabled)
#
# Value ranges (from CIS PDF / Microsoft docs):
#   PasswordHistorySize : 0-24   (CIS: 24 or more -> we set 24, the maximum)
#   MaximumPasswordAge  : 0-999  (CIS: 365 or fewer, but not 0 -> we set 365)
#   MinimumPasswordAge  : 0-999  (CIS: 1 or more -> we set 1)
#   MinimumPasswordLength: 0-20  (CIS: 14 or more -> we set 14)
#   PasswordComplexity  : 0 or 1 (CIS: Enabled -> 1)
#   ClearTextPassword   : 0 or 1 (CIS: Disabled -> 0)

Write-Log "--- Building CIS-compliant security template (.inf) ---"

$InfPath = "$env:SystemRoot\Temp\CIS_PasswordPolicy_$(Get-Date -Format 'yyyyMMdd_HHmmss').inf"
$SdbPath = "$env:SystemRoot\Temp\CIS_PasswordPolicy.sdb"

# Build .inf content as a here-string
$infContent = @"
[Unicode]
Unicode=yes
[Version]
signature="`$CHICAGO`$"
Revision=1
[System Access]
; ─────────────────────────────────────────────────────────────────────────────
; CIS 1.1.1  Enforce password history
; CIS Control ID (from PDF): 1.1.1, GRID: MS-00000001
; Recommended: 24 or more password(s)
; Rationale: Prevents users from cycling through a small pool of passwords,
;            which would undermine the password change requirement.
; NOTE: Microsoft's current maximum is 24. We set exactly 24.
; UI Path: Computer Configuration\Policies\Windows Settings\Security Settings\
;          Account Policies\Password Policy\Enforce password history
; ─────────────────────────────────────────────────────────────────────────────
PasswordHistorySize = 24

; ─────────────────────────────────────────────────────────────────────────────
; CIS 1.1.2  Maximum password age
; CIS Control ID (from PDF): 1.1.2, GRID: MS-00000002
; Recommended: 365 or fewer days, but not 0
; Rationale: Limits the window of opportunity for a cracked/stolen password
;            to be exploited. Setting to 0 (never expires) is a major risk.
; We set 365 (the maximum recommended value). Adjust lower if your policy allows.
; UI Path: Computer Configuration\Policies\Windows Settings\Security Settings\
;          Account Policies\Password Policy\Maximum password age
; ─────────────────────────────────────────────────────────────────────────────
MaximumPasswordAge = 365

; ─────────────────────────────────────────────────────────────────────────────
; CIS 1.1.3  Minimum password age
; CIS Control ID (from PDF): 1.1.3, GRID: MS-00000003
; Recommended: 1 or more day(s)
; Rationale: Prevents users from immediately cycling through passwords to
;            circumvent the password history setting. Must be > 0 for history
;            to be effective.
; UI Path: Computer Configuration\Policies\Windows Settings\Security Settings\
;          Account Policies\Password Policy\Minimum password age
; ─────────────────────────────────────────────────────────────────────────────
MinimumPasswordAge = 1

; ─────────────────────────────────────────────────────────────────────────────
; CIS 1.1.4  Minimum password length
; CIS Control ID (from PDF): 1.1.4, GRID: MS-00000004
; Recommended: 14 or more character(s)
; Rationale: Longer passwords have exponentially more combinations, making
;            brute force attacks far harder. 14 chars is the CIS minimum.
; NOTE: If you need > 14, you must also enable 1.1.6 (Relax min pwd length)
;       on Member Servers. DCs in WS2025 support up to 20 via GPME natively.
; UI Path: Computer Configuration\Policies\Windows Settings\Security Settings\
;          Account Policies\Password Policy\Minimum password length
; ─────────────────────────────────────────────────────────────────────────────
MinimumPasswordLength = 14

; ─────────────────────────────────────────────────────────────────────────────
; CIS 1.1.5  Password must meet complexity requirements
; CIS Control ID (from PDF): 1.1.5, GRID: MS-00000005
; Recommended: Enabled (1)
; Rationale: Requires passwords to contain chars from 3+ of 5 categories
;            (uppercase, lowercase, digits, non-alpha, unicode). Prevents
;            purely alphabetic passwords which are trivially cracked.
; UI Path: Computer Configuration\Policies\Windows Settings\Security Settings\
;          Account Policies\Password Policy\Password must meet complexity requirements
; ─────────────────────────────────────────────────────────────────────────────
PasswordComplexity = 1

; ─────────────────────────────────────────────────────────────────────────────
; CIS 1.1.7  Store passwords using reversible encryption
; CIS Control ID (from PDF): 1.1.7, GRID: MS-00000007
; Recommended: Disabled (0)
; Rationale: Reversibly-encrypted passwords are essentially plaintext. If the
;            AD database were compromised, all passwords would be exposed.
;            Only enable if CHAP/IIS Digest Auth is explicitly required.
; UI Path: Computer Configuration\Policies\Windows Settings\Security Settings\
;          Account Policies\Password Policy\Store passwords using reversible encryption
; ─────────────────────────────────────────────────────────────────────────────
ClearTextPassword = 0
"@

Set-Content -Path $InfPath -Value $infContent -Encoding Unicode
Write-Log "Security template written to: $InfPath"


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 4 : Apply the security template via secedit.exe
# ─────────────────────────────────────────────────────────────────────────────

Write-Log "--- Applying security template via secedit.exe ---"
Write-Log "IMPACT WARNING: This will immediately modify the local security policy."
Write-Log "                In a domain, this applies to the local policy database."
Write-Log "                For domain-wide effect, import this .inf into the"
Write-Log "                Default Domain Policy via GPMC."

# Remove stale .sdb if it exists (secedit creates a new database)
if (Test-Path $SdbPath) { Remove-Item $SdbPath -Force }

# /configure  : apply settings
# /db         : temporary security database path
# /cfg        : our .inf template
# /overwrite  : overwrite the database rather than merge (ensures clean state)
# /areas SECURITYPOLICY : only touch Security Policy area (not user rights etc.)
# /quiet      : suppress the GUI progress dialog
$seceditArgs = @(
    '/configure',
    '/db', $SdbPath,
    '/cfg', $InfPath,
    '/overwrite',
    '/areas', 'SECURITYPOLICY',
    '/quiet'
)

Write-Log "Running: secedit.exe $($seceditArgs -join ' ')"
$result = & secedit.exe @seceditArgs 2>&1
$exitCode = $LASTEXITCODE

Write-Log "secedit exit code: $exitCode"
Write-Log "secedit output   : $result"

if ($exitCode -eq 0) {
    Write-Log "secedit completed successfully. Password Policy settings applied." 'INFO'
}
else {
    Write-Log "secedit returned non-zero exit code ($exitCode). Review output above." 'WARN'
    Write-Log "Settings may be partially applied. Check the secedit log at:" 'WARN'
    Write-Log "  $env:SystemRoot\Security\Logs\scesrv.log" 'WARN'
}


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 5 : CIS 1.1.6 - Relax minimum password length limits
#             (Member Server ONLY - NOT Domain Controllers)
#             Applied via registry (the authoritative backing store per CIS PDF)
#
# From CIS PDF page 49:
#   "This group policy setting is backed by the following registry location
#    with a REG_DWORD value of 1."
#   HKLM\System\CurrentControlSet\Control\SAM:RelaxMinimumPasswordLengthLimits
#
# CIS Scope: Level 1 - Member Server ONLY
# This allows MinimumPasswordLength to be set higher than 14 on local accounts.
# On DCs, domain password policy is managed differently and this key is not
# applicable in the same way (CIS explicitly excludes DCs from this control).
# ─────────────────────────────────────────────────────────────────────────────

Write-Log "--- CIS 1.1.6: Relax minimum password length limits (Member Server only) ---"

if ($isDC) {
    Write-Log "Skipping 1.1.6: This machine is a Domain Controller." 'WARN'
    Write-Log "CIS 1.1.6 is scoped to Level 1 - Member Server only. Not applied." 'WARN'
}
else {
    Write-Log "Applying 1.1.6: Setting RelaxMinimumPasswordLengthLimits = 1 (Enabled)"
    Write-Log "Registry path: HKLM\System\CurrentControlSet\Control\SAM"
    Write-Log "Value name   : RelaxMinimumPasswordLengthLimits"
    Write-Log "Value data   : 1 (REG_DWORD)"
    Write-Log "Rationale    : Allows local accounts to enforce passwords longer than"
    Write-Log "               14 characters. Without this, MinimumPasswordLength is"
    Write-Log "               capped at 14 on older Windows versions."

    try {
        $regPath = 'HKLM:\System\CurrentControlSet\Control\SAM'
        # Read current value for logging before we change it
        $currentVal = (Get-ItemProperty -Path $regPath -Name 'RelaxMinimumPasswordLengthLimits' -ErrorAction SilentlyContinue).RelaxMinimumPasswordLengthLimits
        Write-Log "Current registry value: $currentVal (null = not set)"

        Set-ItemProperty -Path $regPath -Name 'RelaxMinimumPasswordLengthLimits' -Value 1 -Type DWord -Force
        Write-Log "1.1.6 registry value set successfully." 'INFO'
    }
    catch {
        Write-Log "ERROR applying 1.1.6 registry key: $_" 'ERROR'
        Write-Log "You may need to set this manually or via GPMC." 'WARN'
    }
}


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 6 : Verification - read back the applied settings
# ─────────────────────────────────────────────────────────────────────────────

Write-Log "--- Verifying applied settings (secedit /export readback) ---"

$VerifyInfPath = "$BackupDir\PostChange_Verify.inf"
secedit.exe /export /cfg "$VerifyInfPath" /quiet 2>&1 | Out-Null

if (Test-Path $VerifyInfPath) {
    $verifyContent = Get-Content $VerifyInfPath -Raw

    # Parse and log each expected value
    $checks = @{
        'PasswordHistorySize'  = '24'
        'MaximumPasswordAge'   = '365'
        'MinimumPasswordAge'   = '1'
        'MinimumPasswordLength'= '14'
        'PasswordComplexity'   = '1'
        'ClearTextPassword'    = '0'
    }

    Write-Log "--- Setting verification results ---"
    foreach ($key in $checks.Keys) {
        # Match "Key = Value" pattern (case-insensitive, whitespace-tolerant)
        if ($verifyContent -match "(?im)^\s*$key\s*=\s*(\S+)") {
            $foundVal = $Matches[1]
            $expected = $checks[$key]
            if ($foundVal -eq $expected) {
                Write-Log "  [PASS] $key = $foundVal (expected: $expected)"
            }
            else {
                Write-Log "  [MISMATCH] $key = $foundVal (expected: $expected)" 'WARN'
            }
        }
        else {
            Write-Log "  [NOT FOUND] $key not present in exported policy" 'WARN'
        }
    }

    # Verify 1.1.6 on member servers
    if (-not $isDC) {
        $regVal = (Get-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\SAM' `
                   -Name 'RelaxMinimumPasswordLengthLimits' -ErrorAction SilentlyContinue).RelaxMinimumPasswordLengthLimits
        if ($regVal -eq 1) {
            Write-Log "  [PASS] RelaxMinimumPasswordLengthLimits = 1 (Enabled) [1.1.6]"
        }
        else {
            Write-Log "  [MISMATCH] RelaxMinimumPasswordLengthLimits = $regVal (expected: 1) [1.1.6]" 'WARN'
        }
    }
}
else {
    Write-Log "WARNING: Could not export policy for verification." 'WARN'
}


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 7 : Force Group Policy refresh (optional but recommended)
# ─────────────────────────────────────────────────────────────────────────────

Write-Log "--- Forcing Group Policy update ---"
Write-Log "Running: gpupdate.exe /force"

$gpupdateResult = & gpupdate.exe /force 2>&1
Write-Log "gpupdate output: $gpupdateResult"


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 8 : Summary
# ─────────────────────────────────────────────────────────────────────────────

Write-Log "======================================================================"
Write-Log "CIS Section 1.1 Password Policy - Script Complete"
Write-Log ""
Write-Log "Settings applied:"
Write-Log "  1.1.1  Enforce password history            = 24 passwords"
Write-Log "  1.1.2  Maximum password age                = 365 days"
Write-Log "  1.1.3  Minimum password age                = 1 day"
Write-Log "  1.1.4  Minimum password length             = 14 characters"
Write-Log "  1.1.5  Password complexity requirements    = Enabled"
Write-Log "  1.1.6  Relax minimum pwd length limits     = $(if($isDC){'SKIPPED (DC)'}else{'Enabled (registry)'})"
Write-Log "  1.1.7  Store passwords reversible encrypt  = Disabled"
Write-Log ""
Write-Log "Backup location: $BackupDir"
Write-Log "Log file       : $LogFile"
Write-Log ""
Write-Log "NEXT STEPS:"
Write-Log "  1. To apply domain-wide, import $InfPath into the Default Domain"
Write-Log "     Policy GPO via: GPMC > Default Domain Policy > Edit >"
Write-Log "     Computer Config > Windows Settings > Security Settings >"
Write-Log "     Right-click 'Security Settings' > Import Policy"
Write-Log "  2. Run the companion script for Section 1.2 Account Lockout Policy."
Write-Log "  3. Review this script output and validate against CIS PDF v1.0.0."
Write-Log "  4. This script is NOT a guarantee of full CIS compliance."
Write-Log "     Human review and testing in a non-production environment is required."
Write-Log "======================================================================"

<#
================================================================================
ROLLBACK INSTRUCTIONS
================================================================================
To revert ALL changes made by this script:

1. Restore Password Policy settings:
   Run in an elevated PowerShell console:

   secedit.exe /configure /db "$env:SystemRoot\Temp\CIS_PasswordPolicy_rollback.sdb" `
               /cfg "<path-to-backup>\PreChange_SecurityPolicy_Backup.inf" `
               /overwrite /areas SECURITYPOLICY /quiet

   Replace <path-to-backup> with the BackupDir path shown in the script log.

2. Rollback 1.1.6 registry key (Member Servers only):
   Run in an elevated PowerShell console:

   Remove-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\SAM' `
                       -Name 'RelaxMinimumPasswordLengthLimits' -ErrorAction SilentlyContinue

   Or set it back to 0 if it was previously 0:
   Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\SAM' `
                    -Name 'RelaxMinimumPasswordLengthLimits' -Value 0 -Type DWord

3. Force GP update: gpupdate.exe /force

IMPORTANT: If you deployed these settings via the Default Domain Policy GPO
(via GPMC import), you must revert them there too, as GPO refresh will
re-apply GPO-configured values and overwrite local secedit changes.
================================================================================
#>
